const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  _id:{type:String , required:true},
  Product_id: { type: String ,required:true},
  Seller:{ type: String ,required:true},
  UPC: {type:String,required:true },
  Title:{type:String,required:true},
  Price:{type:Number,required:true},
  Competitor:{type:Number,required:true},
  Discount:{type:Number,required:true},
  QuantityAvail:{type:Number,required:true},
  QuantityDemanded:{type:Number,required:true},
  Size:{type:String , required:true , default:'OS'},
  expireAt: { type: Date ,required:true},
  Color:{type:String ,required:true},
  Gender:{type:String,required:true},
  Category:{type:String,required:true},
  Img:[{type : String,required:true}],
});

ProductSchema.index({"expireAt":1},{expireAfterSeconds:0},function(error, indexName){
    if(error) console.log(error);
    console.log(indexName);});

const CartSchema = new mongoose.Schema ({
  _id: {type:String ,required:true },
	Products: [ProductSchema],
	Total:{type:Number , required:true}
});

module.exports = CartSchema;
