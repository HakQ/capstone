'use strict';
const mongoose = require('mongoose');
const Cart = require('cart');
let conn = null;
const uri =process.env.Mongo_uri;

//checks if the quantity demanded for an item is not greater than what is availabel 
function qtyCheck(qtyAvail,qtyDemand)
{
			//not a number 
			if(typeof(qtyAvail)!="number" || typeof(qtyDemand)!="number")
			{
				return 'Qty is invalid';
			}
			//qty is negative or more than 10 is demanded(prohibited by snap cha ching rules)
			else if(qtyDemand>10 || qtyDemand<1)
			{
				return 'The ammount requested was not available';
			}
			
			else
			{
				if(qtyAvail<qtyDemand && qtyAvail!=qtyDemand )
				{
							return false;
				}
				
				return true;
			}
}

function create_err_response(err)
{
	return {
				statusCode: 404,
				headers: {
							'Access-Control-Allow-Origin': '*',
     						 'Access-Control-Allow-Credentials': true,
							  'Content-Type': 'application/json',
						},
				body: JSON.stringify(err)
				
			};
}

function create_response(message)
{


		return {
					statusCode: 200,
					headers: {
							   'Access-Control-Allow-Origin': '*',
     							 'Access-Control-Allow-Credentials': true,
									'Content-Type': 'application/json',
						},
					body: JSON.stringify(message)
				};
	
}


exports.cart = async (event,context) => {

  // Make sure to add this so you can re-use `conn` between function calls.
  // See https://www.mongodb.com/blog/post/serverless-development-with-nodejs-aws-lambda-mongodb-atlas
  context.callbackWaitsForEmptyEventLoop = false;

  // Because `conn` is in the global scope, Lambda may retain it between
  // function calls thanks to `callbackWaitsForEmptyEventLoop`.
  // This means your Lambda function doesn't have to go through the
  // potentially expensive process of connecting to MongoDB every time.
  var c;
  try{
	  if (conn == null) {
	    conn = await mongoose.createConnection(uri, {
	      // Buffering means mongoose will queue up operations if it gets
	      // disconnected from MongoDB and send them when it reconnects.
	      // With serverless, better to fail fast if not connected.
	      bufferCommands: false, // Disable mongoose buffering
	      bufferMaxEntries: 1 // and MongoDB driver buffering
	    });
	    conn.model('Cart', Cart);
	  }
	  c = conn.model('Cart');
  }catch(err){
  			return create_err_response('Lost Connection');
  }
  

	//return createNew(c,event);
  let body = JSON.parse(event.body);
  //let body =event;

  //checks for the proper operation
  if(body.operation == "ADD")
  {
  				return add(c,body);
  }
  
  else if (body.operation == "REMOVE")
  {
			return remove(c,body);
  }
  
  else if(body.operation == 'RETRIEVE')
  {
  		return retrieve(c,body);
  }

  else
  {
  		return create_err_response('INVALID OPERATION');
  }
  
  
};

async function retrieve(cart,event)
{
	let cartid=event.cart_id;
	// by using the cartid find one document 
	//return a promise to finish executing query
		return new Promise(function(resolve,reject){	
						cart.findOne({ _id:cartid},
							 function(err,result)
							 {
									//callback function 
									if(err)
									{
										resolve(create_err_response(err));
									}
									//no cart found
									else if(result==null)
									{
										resolve(create_response(result.Products));
									}
									//no products in the subdoc found
									else if(result!=null && result.Products.length!=0)
									{
										resolve(create_response('Im empty fill me up'));
									}
					
									else
									{
										 resolve(create_response('Im empty fill me up'));
									}
							}
					 );
});
}

//creates new cart
async function createNew(cart,event){
	
	const cart_id=event.cart_id;
	const PID=event.PID;
  	const id=event.Product_id;
    const UPC = event.UPC;
    const seller= event.Seller_id;
    const title = event.Title;
	const total=event.Price*event.QuantityDemand;
	const competitor= event.Competitor;
    const discount=event.Discount;
    const qtyAvail = event.Quantity;
    const qtyDemand = event.QuantityDemand;
    const size= event.Size;
  	const color= event.Color;
	const brand = event.Brand;
	const img= event.IMG;
	const gender = event.Gender;
	const category = event.Category;
    const date=event.expireAt;
    const zipcode=event.ZipCode;
	
	return new Promise(function(resolve,reject){	
		

					try{
						//find a cart
						cart.findOneAndUpdate({ "_id": cart_id},
						  //push the product to the subdoc array
					      {$push: 
									 {
										Products:
										{
												  _id:PID,
												  Product_id:id,
												  UPC:UPC,
												  Title:title,
												  Price:total,
												  Competitor:competitor,
												  Discount:discount,
												  QuantityAvail:qtyAvail,
												  QuantityDemanded:qtyDemand,
												  Seller:seller,
												  Size:size,
												  ZipCode:zipcode,
												  Color:color,
												  Brand:brand,
												  IMG:img,
												  Gender:gender,
												  Category:category,
												  expireAt:date
									 	}
									 },$inc:{Total:total} //increment the total
							 },
							 { upsert: true, new: true,setDefaultsOnInsert:true,returnNewDocument:true}, //upsert doc if it doesnt exist
							 function(err,result)
							 {
							 		
									if(err)
									{
										resolve(create_err_response(err));
									}
									//if the call back value isnt null then successfully added
									else if(result!=null && result.Products.length>0)
									{
														resolve(create_response('successfully added'));
									}
					
									else
									{
										 resolve(create_response('Something went wrong'));
									}
							}
					 );
					 
					}catch(e){
				resolve(create_err_response('Cannot be added to cart'));
}
}); 
}

//add to cart
async function  add (cart , event)
{

  	const cart_id=event.cart_id;
  	const id=event.Product_id;
    const UPC = event.UPC;
    const seller= event.Seller_id;
    const title = event.Title;
	const total=event.Price;
	const competitor= event.Competitor;
    const discount=event.Discount;
    const qtyAvail = event.Quantity;
    const qtyDemand = event.QuantityDemand;
    const size= event.Size;
  	const color= event.Color;
	const brand = event.Brand;
	const img= event.IMG;
	const gender = event.Gender;
	const category = event.Category;
    const date=event.expireAt;

	//if quantity check fails
    if(qtyCheck(qtyAvail,qtyDemand)==false)
    {
    			return create_response('More than what is available was demanded');
    }
    
      
	
	return new Promise ( function (resolve,reject){

			try{
				
					cart.findOne({ "_id": cart_id},
								 {Products:{$elemMatch:{Product_id:id}}},
								 function (err,doc)
								 {
								 				//error exists
								 				//resolve(doc);
								 				if(err)
								 				{
								 					resolve(create_response(err));
								 				}
								 				//didnt find that cart/item so call create new to add it and possibly create the cart if it doesnt exist
								 				else if(doc==null || (doc!=null && doc.Products==null) || (doc!=null && doc.Products!=null && doc.Products.length==0))
								 				{
								 					resolve(createNew(cart,event));
								 				}
								 				//cart and product exists so call change to change the qty demanded
								 			   	else 	if( doc.Products.length==1)
								 				  {
											 					var e = {
																						  "cart_id": cart_id,
																						  "Product_id": id,
																						  "QuantityDemand": qtyDemand
											 					};
											 					resolve(change(cart,e));
								 				  }
													
													else
													{
													resolve(create_err_response('That item cannot be added right now')+doc.Product.length);
													}
								 				
								 }
								 
					);
			  }catch(err){
					resolve(create_err_response(err));
			   }
			
	 });
};

//remove item from cart 
async function remove(cart,event)
{
			var id=event.PID;
		    var cartid=event.cart_id;
		    var k;
			//return a promise to complete query/update
			return new Promise (function(resolve,reject) {
				
			try{	
				 var g= cart.findOne
						(
										{ '_id':event.cart_id},
										function(err, doc)
										{
											if(err!=null )
											{
											 	resolve(create_err_response(err));
											}
											 
											 else if(doc==null)
											 {
											 	resolve(create_err_response('Could not find that item'));
											 }
											 //find subdoc using id,change the total and finally remove the item
											 else if (doc.Products!=null && doc.Products.length>0)
											 {
											 	try {
												 	var t= doc.Products.id(id);
												 	doc.Total = doc.Total-t.QuantityDemanded*t.Price;
												 	var d = doc.Products.id(id).remove();
												 	resolve(doc.save());
												 	resolve(create_response('Item deleted'));
											 	}catch(err){
											 			resolve(create_err_response(err));
											 	}
											 }
											 
											 else{
											 		resolve(create_err_response('Something went wrong'));
											 }
										}
						);
			}catch(err){
						resolve(create_err_response(err));
			}
			
		});
};


//change the amount demanded
function change(cart,event)
{
	var cartid=event.cart_id;
	var productid=event.Product_id;
	var qtyDemand=event.QuantityDemand;
	
	return new Promise 
	( 
			  function (resolve,reject)
			  {
			  	
			  	try{
									cart.findOne({ "_id": cartid },
												 {Products:{$elemMatch:{Product_id:productid}}},
												{ select:{"Total":1}} ,
												  function (err,doc)
												  {			
												  	
														if(err) 
														{
															resolve(create_err_response(err));
														}
														
														//found a single product in the cart
														else if(doc!=null && doc.Products!=null && doc.Products.length==1)
														{
															  //if the quantity checks out
															  if(qtyCheck(doc.Products[0].QuantityAvail,qtyDemand)==true)
															  {
																	//update the total and quantity the user demanded
															  		try{
																				doc.Total=(doc.Total-(doc.Products[0].QuantityDemanded*doc.Products[0].Price))+(qtyDemand*doc.Products[0].Price);
																				//resolve(((doc.Total)-(doc.Products[0].QuantityDemanded*doc.Products[0].Price)));
																			    doc.Products[0].QuantityDemanded=qtyDemand;
																			    doc.save(function(err){if(err)resolve(err)});
																				resolve(create_response('Succesfully updated'));
															  		}catch(err){
															  			resolve(create_err_response("Could not be added to cart"));
															  		}
														   	  }
														   	
														   	  else 
														   	  {
																resolve(create_err_response('The ammount requested was invalid'));
														   	  }
														}
				
														else
														{
														//	resolve(doc);
																	resolve(create_err_response('Item or cart doesnt exists'));
														}
												}
								);
			 }catch(err){
			 				resolve(create_err_response(err));
			 }
			
	 });
			  

};

