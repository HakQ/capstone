'use strict';

const https = require('https');
var result;


function create_err_response(err)
{
	return {
				statusCode: 404,
				body: JSON.stringify(err),
			  headers: { 'Content-Type': 'application/json',
			  	'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': true
			  }
			};
}

function create_response(message)
{


		return {
					statusCode: 200,
					headers: { 'Content-Type': 'application/json'},
					body: JSON.stringify(message)
	    };
	
}

exports.handler = async (event,context) => {

//start a promise for the https call to UPCite	

	 return new Promise(function(resolve, reject) 
{
	  //Calling the API using the following route and header, change route when upgrading to paid version
      const options = 
      {
				  hostname: 'api.upcitemdb.com',
				  path: '/prod/trial/lookup',
				  method: 'POST',
				  headers: {"Content-Type": "application/json"}
	  }

	  //create request 
	  
	  
      var req = https.request(options, function(res) {  
        res.on('data', function(data) {
        	
				try{ 
					   let object = JSON.parse(data);
					  //resolve(create_response(object.code));

						if(object==null || object.code=="NOT_FOUND" )
						{
							var err = 'Product was not found, please try posting manually';
							resolve(create_response(err));
						}

					    else if (object.code=="INVALID_UPC")
					    {
								var err = 'The barcode scanned was invalid';
			
								resolve(create_err_response(err));
					   
                        }

					    else if(object.code=="EXCEED_LIMIT" || object.code=="SERVER_ERR" || object.code=="INVALID_UPC" || 		                       object.code=="HTTP_TOO_MANY_REQUESTS" || object.code=="TOO_FAST")
					    {
								var err =' a Something went wrong please try again shortly';
								resolve(create_err_response(err));	
					    }
				
											  
					    else if(object.items.length!=0)
					    {										  	
								result= object.items[0];
								
						 }

						 else
						 {
							 var error = 'Something went wrong';
				
								 resolve(create_err_response(error));
						 }	
						 
				}catch(err){
							var error ='Something went wrong';
							resolve(create_err_response(error));
				}
	
        });

        res.on('end', function(){ resolve(create_response(result)); });

      });

      req.on('error', function(e) {

				var err = 'Something went wrong please try again shortly';
		

				resolve(create_response(e));

     });

     try {
     	 if (event.body == null && body.body == undefined)
	  {
				return create_err_response('BAD PAYLOAD');
	  }
     	let body = JSON.parse(event.body);
     	//write the upc value to the body of the request
	    req.write(JSON.stringify(body));
	 }catch(err){
			resolve(err)
	 }
      	
	 req.end();
      
});


};
