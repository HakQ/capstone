"use strict";
const pg = require("pg");
const mongoose = require('mongoose');
let conn = null; 
var Schema = mongoose.Schema; //mongo schema
const uri =process.env.Mongo_uri; //grab mongo connection uri
const uuidv4 = require('uuid/v4');  // -> '110ec58a-a0f2-4ac4-8393-c866d813b8d1' creates unique uuid for our product



///return http header as per lambda requirements (For errors)
function create_err_response(err)
{
	return {
				statusCode: 404,
				headers: {
							'Access-Control-Allow-Origin': '*',
     						 'Access-Control-Allow-Credentials': true,
							  'Content-Type': 'application/json',
						},
				body: JSON.stringify(err)
				
			};
}
///return http header as per lambda requirements (For general response)
function create_response(message)
{


		return {
					statusCode: 200,
					headers: {
							   'Access-Control-Allow-Origin': '*',
     							 'Access-Control-Allow-Credentials': true,
									'Content-Type': 'application/json',
						},
					body: JSON.stringify(message)
				};
	
}

//Main function for lambda, this functions purpose is to take the order data provided from the front-end and store it into our postgresSQL database, and to update the mongodb database
//Generally used to grab the product information itself. This database is meant for long term storage/checkup.
module.exports.order = async function(event, context) {
  
     // Make sure to add this so you can re-use `conn` between function calls.
  // See https://www.mongodb.com/blog/post/serverless-development-with-nodejs-aws-lambda-mongodb-atlas
 context.callbackWaitsForEmptybodyLoop = false;
 let body = JSON.parse(event.body);
  // Because `conn` is in the global scope, Lambda may retain it between
  // function calls thanks to `callbackWaitsForEmptybodyLoop`.
  // This means your Lambda function doesn't have to go through the
  // potentially expensive process of connecting to MongoDB every time.
  var products;
  //Tries to connect to mongodb database to grab all required data for long term storage per order, saves the data to products
  try
  {
          if (conn == null) {
            conn = await mongoose.createConnection(uri, {
              // Buffering means mongoose will queue up operations if it gets
              // disconnected from MongoDB and send them when it reconnects.
              // With serverless, better to fail fast if not connected.
              bufferCommands: false, // Disable mongoose buffering
              bufferMaxEntries: 0 // and MongoDB driver buffering
            });
             conn.model('products', Schema({
          _id: { type: String, default:  function genUUID(){ return uuidv4();}},
          Product_id: { type: String , required:true},
          UPC: {type:String , required:true},
          Seller_id:{ type:String , required:true},
          Title:{type:String,required: true},
          Price:{type:Number,required: true},
          Competitor:{type:Number},
          Discount:{type:Number},
          Quantity:{type:Number,required:true},
          Size:{type:String , required:true , default:'OS'},
          Description:{type:String, default:'No Description Available'},
          expireAt: { type: Date , required:true },
          Color:{type:String , required:true},
          Gender:{type:String, require:true},
          Category:{type:String , required:true},
          Zip_Code:{type:String , required:true},
          IMG:{type : String},
          SoldOut:{type:Boolean , default:false}
        }, { collection : 'products' }));
           
          }
           products = conn.model('products');
  }catch(err){
        return create_err_response('Could not connect');
  }
  
 

  //Postgres url to connect data, we then check if the database is created, else, we create the database using the below schema
  var conString =
    "postgres://xbulgyrc:QyR4qlQFtDu7aGzS6Abos4PTUr6EVYKq@isilo.db.elephantsql.com:5432/xbulgyrc"; //Can be found in the Details page
  var client = new pg.Client(conString);
  var inputData = body;
  var commands = [
    " CREATE TABLE  IF NOT EXISTS order_table ( order_UUID VARCHAR(256) UNIQUE PRIMARY KEY,  seller_ID VARCHAR(64) NOT NULL, customer_ID VARCHAR(64) NOT NULL, orders_info VARCHAR(6000) NOT NULL)",
    " CREATE TABLE  IF NOT EXISTS user_wrapper (customer_ID VARCHAR(64) UNIQUE PRIMARY KEY, customer_Name VARCHAR(64) NOT NULL)",
    " CREATE TABLE  IF NOT EXISTS sale_information (seller_ID VARCHAR(64) UNIQUE PRIMARY KEY,generic_ID VARCHAR(64) NOT NULL,product_UUID VARCHAR(256) NOT NULL)",
    " CREATE TABLE  IF NOT EXISTS seller_wrapper ( seller_ID VARCHAR(64) UNIQUE PRIMARY KEY, email VARCHAR(128) UNIQUE)",
    " CREATE TABLE  IF NOT EXISTS shipping_info (customer_ID VARCHAR(64) UNIQUE PRIMARY KEY, shipping_add VARCHAR(128))"
  ];
  return new Promise(function(resolve, reject) {
    //Update our product based on the UUID in which, we change it based on the order being proceed
    try{
        products.findOne({'_id': body.Product_UUID},  
                            function(err,obj) 
                            { 
                              if(err)
                              {
                                resolve(create_err_response(err))
                              }
                              
                              else if(obj==null || (obj!=null && obj.SoldOut==true))
                              {
                                  resolve(create_err_response('Product not available'));
                                  return;
                              }
                              
                              else
                              {
                                obj.Quantity=obj.Quantity-body.QuantityDemanded;
                                if(obj.Quantity==0)
                                {
                                  obj.SoldOut=true;
                                }
                                obj.save();
                              }
                            }
       );
                             
      
    }
    catch(err){
      resolve(create_err_response(err))
    }
    
    //Connect to postgres, use the information from our order to catalog into separate tables based on the information give. Order_Table for order information,
    //user_wrapper for user information, sale_information for general sell information, etc. After it is done we return the unique UUID we created
    try {
      client.connect(function(err) {
        if (err) {
          resolve(create_err_response("could not connect to postgres", err));
        }
        for (var pos = 0; pos < commands.length; pos++) {
          console.log(commands[pos]);
          //pool.query(commands[pos]),
          client.query(commands[pos], (err, res) => {
            console.log(err, res);
          });
        }

        var uuidObj = uuidv4();
        inputData["Order_UUID"] =  uuidObj;
        var tempObj = JSON.stringify(inputData);
        
        client.query(
          "INSERT INTO order_table (order_UUID, seller_ID, customer_ID, orders_info) VALUES ($1, $2, $3, $4)",
          [
		      inputData.Order_UUID,
          inputData.Seller_ID,
			    inputData.Customer_ID,
          tempObj
          ],
          (error, results) => {
            if (error) {
              resolve(create_err_response("Already exists1"));
            }
          }
        );
        
        
         client.query(
          "INSERT INTO sale_information (seller_ID, generic_ID, product_UUID) VALUES ($1, $2, $3)",
          [
            inputData.Seller_ID,
			      inputData.Product_ID,
            inputData.Product_UUID
          ],
          (error, results) => {
            if (error) {
              var returnStr = "Already exists2 UGH $1, $2, $3" + inputData.Seller_ID + inputData.Product_ID+ inputData.Product_UUID;
              resolve(create_err_response(returnStr));
            }
          }
        );
         client.query(
          "INSERT INTO shipping_info (customer_ID, shipping_add) VALUES ($1, $2)",
          [
            inputData.Customer_ID,
            inputData.Shipping_INFO
          ],
          (error, results) => {
            if (error) {
              resolve(create_err_response("Already exists3"));
            }
          }
        );

        client.query(
          "INSERT INTO user_wrapper (customer_ID, customer_Name) VALUES ($1, $2)",
          [
            inputData.Customer_ID,
            inputData.Customer_Name
          ],
          (error, results) => {
            if (error) {
              resolve(create_err_response("Already exists4"));
            }
          }
        );
         client.query(
          "INSERT INTO seller_wrapper (seller_ID, email) VALUES ($1, $2)",
          [
            inputData.Seller_ID,
            inputData.Seller_Email
          ],
          (error, results) => {
            if (error) {
              resolve(create_err_response("Already exists"));
            }
          }
        );
        
        resolve(create_response(uuidObj));
      });
    } catch (e) {
      //resolve (e);
    }
  });

};





