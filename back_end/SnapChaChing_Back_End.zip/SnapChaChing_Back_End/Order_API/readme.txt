# What does this API do?

Simple-order-dev-order-dev-o


This API's function is to create and catalog information regarding an order into our postgreSQL, it updates the mongodb instance we have to ensure that data is correctly cataloged
and removed from the general purpose database. It maintains functions to return http headers per lambda requirements and ensures data is put into a table in postgres even if the table does not exist. This API's purpose is longevity and record holding, it should nor or rather will likely not be used as consistent data gathering; however, definitely as data placement per every order that is created. 