'use strict';
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var shippo = require('shippo')(process.env.Shippo_key);
var sesAccessKey = 'snapchaching@gmail.com'
var sesSecretKey = 'capstone'

function create_err_response(err)
{
	return {
				statusCode: 404,
				body: JSON.stringify(err),
				 headers: {
							'Access-Control-Allow-Origin': '*',
     						 'Access-Control-Allow-Credentials': true,
							  'Content-Type': 'application/json',
						}
			};
}

function create_response(message)
{


		return {
					statusCode: 200,
					body: JSON.stringify(message),
					 headers: {
							'Access-Control-Allow-Origin': '*',
     						 'Access-Control-Allow-Credentials': true,
							  'Content-Type': 'application/json',
						}
				};
	
}


module.exports.Create_Label = async (event) => {
  
 
      if (event.body == null )
  	  {
  				return create_err_response('BAD PAYLOAD');
  	  }
      	  
      	 var body = JSON.parse(event.body);

	//store the array of rates and store the customer email
	//intialize arrays to hold the seller's label and another for the customer's tracking number
	var rates= body.rates;
	var customer_email=body.customer_email;
	var seller_info= new Array();
    var customer_info= new Array();
    if(rates==null || rates.length==0)
    {
    	return create_err_response('No rates');
    }
	var i=0;
	
		//loop through all the rate ids
		for(i=0;i<rates.length;i++)
		{
				try{
						//call the create label function on all rate ids
						//it will return an object with seller's email , seller's label and buyer's tracking number 
						var res = await create_label(rates[i].rate_id,rates[i].seller_email.email);

						//if a call fails its body's status field will be failed
						if(res.status=="FAILED")
						{
							return create_err_response(res.error);
						}

						//create an object for the buyer which will hold their tracking number
						//this information is in the object returned above
						var buyer ={
							track:res.tracking_number,
						};

						//create an object for the seller which will hold their email and their label
						//this information is in the object returned above
						var seller={
							email:res.Seller,
							label:res.label
						};

						//push these objects to their respective arrays 
						seller_info.push(seller);
						customer_info.push(buyer);
						
				}catch(err){
					return create_err_response(err);
				}
				
		}
	
		//set up the nodemailer transport object this gives them access to the snapchaching email address 
	 	var transporter = nodemailer.createTransport(smtpTransport({
		    service: 'gmail',
		    auth: {
		        user: sesAccessKey,
		        pass: sesSecretKey
		    }
	  	}));
	  	
	  	//wait for the send seller email function to complete before attempting to send the buyer and email
	  	var sellerEmailed= await send_seller_email(transporter,seller_info,body.customer_email);

		//if the function completed it will return true
	  	if(sellerEmailed==true)
	  	{
			//execute the buyer Emailed function and await it's completion 
	  		var buyerEmailed=await send_buyer_email(transporter,customer_info,body.customer_email);

			//buyer email failed notify the user the order could not be confirmed
	  		if(buyerEmailed==false)
	  		{
	  			return create_err_response('Order could not be confirmed');
	  		}
	  		
			//buyer email succeeded inform the user the order is confirmed
	  		else{
	  			return create_response('Order Confirmed');
	  		}
	  	}
	  	
	  	else
	  	{
  			return create_err_response('Order Failed');
  		}

}

//wrapper function to send buyers an email
function send_buyer_email(transporter,sellers,email)
{
	var i;
	var	y="";
	//use this for loop to create a string with all the tracking numbers 
	for(i=0;i<sellers.length;i++)
	{
		var track=sellers[i].track;
		y='Track with '+track+' ';
	}
	
		//create a buyer email object including our email , their email , the subject and the string we just created
		var buyer = {
		    from: 'snapchaching@gmail.com',
		    to: email,
		    bcc: '',
		    subject: 'Order Confirmed',
		    text: y
  		};
	
	//call the main function which will send the email that will return boolean value
	return send_email(transporter,buyer);
	
}

//this is similar to the buyer function but instead for sellers
function send_seller_email(transporter,seller)
{

	//loop through all the labels and create a long string for all of them this will be the message in the email
		var i;
	for(i=0;i<seller.length;i++)
	{
		var email=seller[i].email;
		var label=seller[i].label;
		var seller = {
		    from: 'snapchaching@gmail.com',
		    to: email,
		    bcc: '',
		    subject: 'You Got a sale',
		    text: 'You sold an item print this label and ship it '+label
  		};
  		
  		return send_email(transporter,seller);
		
	}
}

//the send email function which will send the emails we provide it
function send_email(transporter,recipient){
	
	
	//return a promise to complete the email request
	return new Promise(function (resolve,reject){
		
		try{
					//using nodemailer we will execute its' send mail function 
				 	transporter.sendMail(recipient, function(error, info){
							//fails to send return false
							  if(error)
							  {
									resolve(false);
							  }
							  
							//succcessfully sends return true
							  else
							  {
							  	resolve(true);
							  }
			    	});
		}catch(err){
				resolve(false);
		}
		});
}

//uses the shippo api to generate a label and send it to the seller
//takes a rate id to generate the label and uses the seller emails so we can know later where to send this label to
function create_label(rate,seller_email){

	return new Promise(function(resolve,reject){
                          
                                // Purchase the desired rate.
                                shippo.transaction.create({
                                    "rate": rate,
                                    "label_file_type": "PDF",
                                    "async": false
                                }, function(err, transaction) {
                                       // asynchronous callback
									   //if failed create and error object and return it
                                        if(err)
                                        {
                                            var res ={
													status:"FAILED",
													error:err
										  }
										  resolve(res);
										  return;
                                        }
                                        
										//if transaction wen through then create a success object
                                        if(transaction!=null)
                                        {
										  //this object will store the seller's label and the buyers tracking number
										  //it also contains the seller's email address in order to know where to send the label 
                                          var order ={
                                          		status:"SUCCESS",
                                    			tracking_number:transaction.tracking_number,
                                            	tracking_url:transaction.tracking_url_provider,
                                            	label:transaction.label_url,
                                          		Seller:seller_email
                                          }
                                          
                                          resolve(order);
                                          return;
                                        }
                                        
                                        else
                                        {
										  var res ={
													status:"FAILED",
													error:'Could not retrieve a label'
										  }
                                           resolve(res);
                                           return;
                                        }
                                });	
                        		

			});

}
