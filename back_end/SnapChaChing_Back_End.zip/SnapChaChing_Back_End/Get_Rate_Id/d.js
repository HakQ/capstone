var cognito = require("amazon-cognito-identity-js");
var AmazonCognitoIdentity = require("amazon-cognito-identity-js");
var AWS = require("aws-sdk");
AWS.config.update({ region: "us-east-1" });
var cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();
var shippo = require('shippo')(process.env.Shippo_key);


function Domestic(country)
{
    if(country.length!=2)
    {
      return false;
    }
    
    else {
      country=country.toUpperCase();
      if(country!='US')
      {
        return false;
      }
        return true;
    }
}

function create_err_response(err)
{
	return {
				statusCode: 404,
				body: JSON.stringify(err),
				headers: {
							'Access-Control-Allow-Origin': '*',
     						 'Access-Control-Allow-Credentials': true,
							  'Content-Type': 'application/json',
						}
			};
}

function create_response(message)
{


		return {
					statusCode: 200,
					body: JSON.stringify(message),
					headers: {
							'Access-Control-Allow-Origin': '*',
     						 'Access-Control-Allow-Credentials': true,
							  'Content-Type': 'application/json',
						}
				};
	
}

function create_rate_response(amount , days)
{
      return {
          statusCode: 200,
          Amount:amount,
          Estimated_Days:days+" business days"
      };
}


exports.create_shipment = async (event) => {
  
  
        /* if (event.body == null )
      	  {
      				return create_err_response('BAD PAYLOAD');
      	  }
      	  
      	 var body = JSON.parse(event.body);
    	  */
        
    	  var body=event;
    	 try{
            
          if(body.addressFrom!=null && body.parcels!=null && body.addressFrom.length!=body.parcels.length)
          {
                    return create_err_response('Missing parcels or addresses');
          }
          var addressTo = {
        				"name": body.addressTo.name,
        				"street1": body.addressTo.street1,
        				"city": body.addressTo.city,
        				"state": body.addressTo.state,
        				"zip": body.addressTo.zip,
        				"country": body.addressTo.country,
        				"email":body.addressTo.email
          };
      
          // return addressTo;
          if(!Domestic(addressTo.country))
          {
              
              return(create_err_response('Sorry , This address is not in the US'));
          }
          
          var valid = validate_address(addressTo);
         // return valid;
          if(valid=='shippo error')
          {
            return create_err_response('Address could not be verified at this time please try again');
          }
          
          else if (valid==false)
          {
              return create_err_response('Address is not valid please input a valid address');
          }
          
          else
          {
              var i=0;
              var results= new Array();
              var total=0;
			  var addressFrom= get_list_of_sellers_addresses(emails);
              return addressFrom;
              for(i=0;i<body.addressFrom.length;i++)
              {
                  var addressFrom = body.addressFrom[i].address;
                  var currResult=await retrieve(addressFrom,addressTo);
                  //return currResult;
                  if(currResult.statusCode==404)
                  {
                    return create_err_response(currResult);
                  }
                  total=total+currResult.Amount;
                  //return create_response(currResult);
                  results.push(currResult);
              }
              return(create_response(results));
          }
          
    	 }catch(err){
    	            return create_err_response(err);
    	 }
}


function get_list_of_seller_addresses(emails)
{
		 var i=0;
		  var y= new Array();
		  var emails=body.emails;
		  for(i=0;i<emails.length;i++)
		  {
			  var x= await get_seller_address(emails[i].email); 
			  if(x=='Could not find seller')
			  {
			  		return x;
			  }
			  y.push(x); 
		  }

		  return y;
}

function get_seller_address(sellername)
{
		  return new Promise(function(resolve, reject) {

			var params = {
			  UserPoolId: "us-east-1_spzaa5D0b" /* required */,
			  AttributesToGet: ["address"], //null,////Filter: 'email = "francis.irizarry52@myhunter.cuny.edu"',
			   Filter: 'email = '+ '\"' + value + '\"',
			  Limit: "20"
			};
		
			try{
				    cognitoidentityserviceprovider.listUsers(params, async function(err, data) {
				      if (err) {
				        resolve(create_response(err, err.stack)); // an error occurred
				      } else {
				         resolve(data.Users[0].Attributes[0].Value);
				         }
				    });
				    
			 }
			catch(err){
				resolve('Could not find seller');
			}
		  });
}

function validate_address(addressTo){
  
      return new Promise(function(resolve,reject){
          
            
                  shippo.address.create({
                    "name":addressTo.name, 
                    "street1":addressTo.street1,
                    "city":addressTo.city,
                    "state":addressTo.state,
                    "zip":addressTo.zip,
                    "country":"US",
                    "validate": true
                }, function(err, address) {
                    try{
                          if(err)
                          {
                            resolve('shippo error');
                          }
                          
                          else if(address!=null && address.validation_results.is_valid==true)
                          {
                                resolve(address);
                          }
                          
                          else if(address!=null && address.validation_results.is_valid==false)
                          {
                                resolve(address);
                          }
                          else
                          {
                                resolve('shippo error')
                          }
                    }catch(err){
                    resolve('shippo error');
                    }
                });
      });

}


function retrieve(addressFrom,addressTo){
  
      return new Promise(function(resolve,reject){
        
           var parcel={
        "length": "5",
        "width": "5",
        "height": "5",
        "distance_unit": "in",
        "weight": "2",
        "mass_unit": "lb"
      }
          
          try{
                  shippo.shipment.create({
                      "address_from": addressFrom,
                      "address_to": addressTo,
                      "parcels": [parcel],
                      "async": false
                  }, function(err, shipment){
                      // asynchronously called	
                    
                    if(err!=null)
                    {
                      resolve(create_err_response(err));
                    }
                    
                  	var i=0;
                  	if(shipment==null)
                  	{
                  	  resolve(create_err_response("Could not create a label for this shipment contact customer service"));
                  	}
                  	
                    else if (shipment)
                    {
                          
                        	for (i=0;i<shipment.rates.length;i++) 
                        	{
                         	 	if(shipment.rates[i].attributes.includes('BESTVALUE') || shipment.rates[i].attributes.includes('CHEAPEST'))
                        		{
                                var rate = shipment.rates[i];
                                var res = {
                                      status:"SUCCESS",
                                      id:rate.object_id,
                                      cost:rate.amount
                                }
                                resolve(create_response(res));
                        		}
                    		  }
                    		  
                    		  resolve('Could not find rate');
                    }
                  
                 });
          }catch(e){
            resolve(create_err_response("Something went wrong"));
          }
        
}
);

 
};
