var cognito = require("amazon-cognito-identity-js");
var AmazonCognitoIdentity = require("amazon-cognito-identity-js");
var AWS = require("aws-sdk");
AWS.config.update({ region: "us-east-1" });
var cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();
var shippo = require('shippo')(process.env.Shippo_key);

//Checks if country is US
function Domestic(country)
{
    if(country.length!=2)
    {
      return false;
    }
    
    else {
      country=country.toUpperCase();
      if(country!='US')
      {
        return false;
      }
        return true;
    }
}

function create_err_response(err)
{
	return {
				statusCode: 404,
				body: JSON.stringify(err),
				headers: {
							'Access-Control-Allow-Origin': '*',
     						 'Access-Control-Allow-Credentials': true,
							  'Content-Type': 'application/json',
						}
			};
}

function create_response(message)
{


		return {
					statusCode: 200,
					body: JSON.stringify(message),
					headers: {
							'Access-Control-Allow-Origin': '*',
     						 'Access-Control-Allow-Credentials': true,
							  'Content-Type': 'application/json',
						}
				};
	
}

function create_rate_response(amount , days)
{
      return {
          statusCode: 200,
          Amount:amount,
          Estimated_Days:days+" business days"
      };
}


exports.create_shipment = async (event) => {
  
         if (event.body == null )
      	  {
      				return create_err_response('BAD PAYLOAD');
      	  }
      	  
      	 var body = JSON.parse(event.body);
    	
        
    	  //var body=event;
    	 try{
            
          if(body.addressFrom!=null && body.parcels!=null && body.addressFrom.length!=body.parcels.length)
          {
                    return create_err_response('Missing parcels or addresses');
          }
	      //create address to object
          var addressTo = {
        				"name": body.addressTo.name,
        				"street1": body.addressTo.street1,
        				"city": body.addressTo.city,
        				"state": body.addressTo.state,
        				"zip": body.addressTo.zip,
        				"country": body.addressTo.country,
        				"email":body.addressTo.email
          };
      
          // check if the address if fromt the us 
          if(!Domestic(addressTo.country))
          {
              
              return(create_err_response('Sorry , This address is not in the US'));
          }
          
		  //use the shippo api to validate address
          var valid = validate_address(addressTo);
       
          if(valid=='shippo error')
          {
            return create_err_response('Address could not be verified at this time please try again');
          }
          
          else if (valid==false)
          {
              return create_err_response('Address is not valid please input a valid address');
          }
          //address is valid so create an id for a label
          else
          {
              var i=0;
              var results= new Array();
              var total=0;
			  //use function to get all seller addresses from email
			  var addressFrom= await get_list_of_seller_addresses(body.emails);
			  // for each seller address create their respective label
              for(i=0;i<addressFrom.length;i++)
              {
                  var AF = addressFrom[i];
				  var email= body.emails[i];
                  var currResult=await retrieve(AF,addressTo,email);
                  if(currResult.statusCode==404)
                  {
                    return create_err_response(currResult);
                  }
				  //add the total cost of these labels
                  total=total+currResult.Amount;
           		  //push these results to an array 
                  results.push(currResult);
              }
              return(create_response(results));
          }
          
    	 }catch(err){
    	            return create_err_response('Something went wrong');
    	 }
}


function get_list_of_seller_addresses(emails)
{

   //wrapper function calls the acutal function which will get seller address from aws 
   return new Promise(async function(resolve,reject){
	try{
		 var i=0;
		  var y= new Array();
		  for(i=0;i<emails.length;i++)
		  {
			  var x= await get_seller_address(emails[i].email); 
			  
			  if(x=='Could not find seller' || x=='err')
			  {
			  		return x;
			  }
			  //parse csv of address
			  var res = x.split(",");
			  var address ={
					"name":'Snap Chaching',
					"street1":res[0],
					"city":res[1],
					"state":res[2],
					"zip":res[3],
					"country":"US"
			   };
			   //push each address to an array 
			   y.push(address); 
		  }

		  resolve(y);
	}catch(err){
			return 'could not find seller';
	}
	});
}

//using the aws pool we can get the address the seller provided when they signed up 
function get_seller_address(sellername)
{
		  return new Promise(function(resolve, reject) {

			var params = {
			  UserPoolId: "us-east-1_spzaa5D0b" /* required */,
			  AttributesToGet: ["address"], //null,////Filter: 'email = "francis.irizarry52@myhunter.cuny.edu"',
			   Filter: 'email = '+ '\"' + sellername + '\"',
			  Limit: "20"
			};
		
			try{
				    cognitoidentityserviceprovider.listUsers(params, async function(err, data) {
				      if (err) {
				        resolve('err'); // an error occurred
				      } else {
				         resolve(data.Users[0].Attributes[0].Value);
				         }
				    });
				    
			 }
			catch(err){
				resolve('Could not find seller');
			}
		  });
}

//use shippo api call to validate the address of the buyer
function validate_address(addressTo){
  
      return new Promise(function(resolve,reject){
          
            
                  shippo.address.create({
                    "name":addressTo.name, 
                    "street1":addressTo.street1,
                    "city":addressTo.city,
                    "state":addressTo.state,
                    "zip":addressTo.zip,
                    "country":"US",
                    "validate": true
                }, function(err, address) {
                    try{
                          if(err)
                          {
                            resolve('shippo error');
                          }
                          
                          else if(address!=null && address.validation_results.is_valid==true)
                          {
                                resolve(address);
                          }
                          
                          else if(address!=null && address.validation_results.is_valid==false)
                          {
                                resolve(address);
                          }
                          else
                          {
                                resolve('shippo error')
                          }
                    }catch(err){
                    resolve('shippo error');
                    }
                });
      });

}

// retrive a rate id in order to obtain a label later
function retrieve(addressFrom,addressTo,email){
  
      return new Promise(function(resolve,reject){
        
           var parcel={
        "length": "5",
        "width": "5",
        "height": "5",
        "distance_unit": "in",
        "weight": "2",
        "mass_unit": "lb"
      }
          
          try{
				 //create a shipment object
                  shippo.shipment.create({
                      "address_from": addressFrom,
                      "address_to": addressTo,
                      "parcels": [parcel],
                      "async": false
                  }, function(err, shipment){
                      // asynchronously called	
                    if(err!=null)
                    {
                      resolve(create_err_response(err));
                    }
                    
                  	var i=0;
                  	if(shipment==null)
                  	{
                  	  resolve(create_err_response("Could not create a label for this shipment contact customer service"));
                  	}
                  	
                    else if (shipment)
                    {
                          //look through all rates and pick the one with the cheapest rate or best value
                        	for (i=0;i<shipment.rates.length;i++) 
                        	{
                         	 	if(shipment.rates[i].attributes.includes('BESTVALUE') || shipment.rates[i].attributes.includes('CHEAPEST'))
                        		{
                                var rate = shipment.rates[i];
                                var res = {
                                      status:"SUCCESS",
                                      rate_id:rate.object_id,
                                      cost:rate.amount,
									  seller_email:email
                                }
                                resolve(create_response(res));
                        		}
                    		  }
                    		  
                    		  resolve('Could not find rate');
                    }
                  
                 });
          }catch(e){
            resolve(create_err_response("Something went wrong"));
          }
        
}
);

 
};
