const mongoose = require('mongoose');
const Product = require('products');
const moment = require('moment-timezone');
let conn = null;

const uri =process.env.Mongo_uri; 

function validify(number)
{
		  if(typeof(number)!='number' || number<0 ||  number>10000)
		  {
			return false;
		  }

		  return true;
};

//determines the total price after 25% profit margin for seller plus us taking 10% from said profit margin
function total_price(seller_paid)
{
		try{
		  seller_paid=Number(seller_paid)
		}
		catch(err){
		  throw (err);
		}
		if(!validify(seller_paid))
		{
		  throw 'Bad value';
		}

		else
		{
		  var seller_profit = seller_paid*.25;
		  var our_profit=seller_profit*.1;
		  var total = Number(seller_paid)+Number(seller_profit)+Number(our_profit);
		  return total;
		}
	};




//checks if its a good deal if it is lower than our competitors by atleast 15%
//checks other sellers on our platform , the deal must match or beat them
function good_deal(seller_paid,competitors_price,other_sellers)
{
	//check if arguments passed are numbers
	 try{
		seller_paid= Number(seller_paid);
		competitors_price=Number(competitors_price);
	  }catch(err){
		  throw err;
	  }

	 try{
			  if(!validify(seller_paid)|| !validify(competitors_price))
			  {
				throw 'Not a number';
			  }
			  else
			  {
					var total=total_price(seller_paid);
					var lowestPrice=lowest_price(other_sellers);
					//if the upc api provides us with competitors info check that the deal beats it
					if(competitors_price!=0 && total>(competitors_price-(competitors_price*.15)))
					{
						return false;
					}
					//if the same product exists on our site check if the deal beats it 
					else if((lowestPrice!='No competitors' && (lowestPrice>total || lowestPrice==total)) || (lowestPrice=='No competitors'))
					{
								return true;
					}
					//the deal could not beat others on our site 
					else
					{
						return false;
					}			
			  }
	  }catch(err){
		 throw total;
	}
};



//Quantity sold must not be greater than 10
function quantity_check(qty)
{
		  try{
			qty=Number(qty);
		  }catch(err){
			throw err;
		  }
		  if(!validify(qty))
		  {
			throw 'Not a number';
		  }

		  else if (qty>10 || qty < 1)
		  {
			return false;
		  }

		  else
		  {
			return true;
		  }
};





//Check if the time provided is not with the 45 minutes to 2 hour range
function sufficient_time(minutes)
{
		  try{
			minutes=Number(minutes);
		  }catch(err){
			throw err;
		  }
		  if(!validify(minutes))
		  {
			throw 'Not a number';
		  }

		  if(minutes < 45 || minutes > 120)
		  {
			  return false;
		  }

		  else {
			return true;
		  }
};

//finds the lowest price from an array of sellers;
function lowest_price(sellers)
{
	var i =0;
	if(sellers.length !=0)
	{
		//lowest starts as the first element
		var lowest=sellers[0].Price;
		
		//for each other seller if one of them is lower swap values
		for(i=1;i<sellers.length;i++)
		{
			if(sellers[i].Price < lowest)
			{
				lowest = sellers[i].Price;
			}	
		}

		//at this point the whole array has been checked and lowest has the correct value
		return lowest;
	}
	
	return 'No competitors';

}

//finds the highest price from an array of sellers
function highest_price(sellers)
{
	var i =0;
	if(sellers.length !=0)
	{
		var highest=sellers[0].Price;
		for(i=1;i<sellers.length;i++)
		{
			if(sellers[i].Price > lowest)
			{
				highest = sellers[i].Price;
			}	
		}

		return highest;
	}
	
	return 'No competitors';

}


function Discount(price_paid,competitor,other_sellers)
{

		  try{
			price_paid=Number(price_paid);
			competitor=Number(competitor);
			highestPrice=highest_price(other_sellers);
		  }catch(err){
			throw err;
		  }
		  if(!validify(competitor) || !validify(price_paid))
		  {
			throw 'Not a number';
		  }


		try{
				 if(competitor!=0)
				 {
				  	return (price_paid/competitor);
				 }
				 else if (highestPrice!='No competitors')
				 {
				  		return (price_paid/highestPrice);
				 }
				 else 
				 {
				  	return 0;
				 }
		}catch(err)
		{
			throw 'failed at discount';	
		};
};

function create_err_response(err)
{
	return {
				statusCode: 404,
				body: JSON.stringify(err),
				headers: {'Content-Type': 'application/json'}
			};
}

function create_response(message)
{


		return {
					statusCode: 200,
					body: JSON.stringify(message),
					headers: {'Content-Type': 'application/json'}
				};
	
}






exports.handler = async function(event, context) {
  // Make sure to add this so you can re-use `conn` between function calls.
  // See https://www.mongodb.com/blog/post/serverless-development-with-nodejs-aws-lambda-mongodb-atlas
  context.callbackWaitsForEmptyEventLoop = false;

  // Because `conn` is in the global scope, Lambda may retain it between
  // function calls thanks to `callbackWaitsForEmptyEventLoop`.
  // This means your Lambda function doesn't have to go through the
  // potentially expensive process of connecting to MongoDB every time.
  if (conn == null) {
    conn = await mongoose.createConnection(uri, {
      // Buffering means mongoose will queue up operations if it gets
      // disconnected from MongoDB and send them when it reconnects.
      // With serverless, better to fail fast if not connected.
      bufferCommands: false, // Disable mongoose buffering
      bufferMaxEntries: 1 // and MongoDB driver buffering
    });
    conn.model('Product', Product);
  }


  const product = conn.model('Product');

	 // if the payload is null 
	  if (event.body == null && body.body == undefined)
	  {
				return create_err_response('BAD PAYLOAD');
	  }
				  //payload not null so parse it 
   			 	  let body = JSON.parse(event.body)
       			  const size= body.Size;
				  const description = body.Description;
				  const img= body.IMG;
				  const UPC = body.UPC;
				  const title = body.Title;
				  const price_paid = body.Price_paid;
				  const competitor= body.Competitor;
				  const qty = body.Qty;
				  const color= body.Color;
				  const time = body.Time;
				  const weight = body.Weight;
				  const seller= body.Seller;
				  const brand = body.Brand;
				  const gender = body.Gender;
				  const category = body.Category;
	 

	//get all competitors of this item
	var os;
	try {
		os = await product.find({UPC:UPC});
	}catch(err){
			console.log(err);
			return create_err_response('could not find upc');
	}

	const other_sellers=os;
	//check if it's a good deal
    try{	
		  if(!good_deal(price_paid,competitor,other_sellers))
		  {
		    return create_response("Sorry , not a good deal");
		  }
    }catch(err){
	  console.log(err);
      return create_err_response(err);
    }
	//check if the quantity is 10 or less
    try{
		  if(!quantity_check(qty))
		  {
		    return create_response('Quantity surpasses our 10 unit limit');
		  }

    }catch(err){
	  console.log(err);
      return create_err_response('something went wrong');
    }

	//check that time is within the 45 minute to 2 hour limit
    try{
		  if(!sufficient_time(time))
		  {
		    return create_response('Not within the 45m to 2hr time range');
		  }
    }catch(err){
	  console.log(err);
      return create_err_response('time is wrong');
    }

    try{
			  //find if the seller is already selling item
			  const duplicate = await product.find({Seller_id:seller,UPC:UPC});
			  
			  // if the array returned is not empty the seller is already selling it
			  if(duplicate.length!=0)
			  {
				  
				  return create_err_response("Sorry , You Can't Post That Again");
			  }
				
			  //once the check passes put values in the document and add to Mongo instance
			  else {
					  let total=total_price(Number(price_paid));
					  let discount= Discount(total,competitor,other_sellers);
					  let id = seller+UPC;
					  var t=Number(time);
					  var date=moment().tz("America/New_York").add(t,'minutes');
					  await product.create({
					  Product_id:id,
					  UPC:UPC,
					  Seller_id:seller,
					  Title:title,
					  Price:total,
					  Competitor:competitor,
					  Discount:discount,
					  Quantity:qty,
					  Size:size,
					  Description:description,
					  Color:color,
					  Brand:brand,
					  Img:img,
					  Gender:gender,
					  Category:category,
					  expireAt:date
					  });
		
						return create_response("Post Successfully Created");
			}
    } catch(err){
      console.log(err);
      return create_err_response(err);
    }
};
